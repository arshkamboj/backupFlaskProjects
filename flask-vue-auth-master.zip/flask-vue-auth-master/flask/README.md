# flask-jwt
Basic Flask JWT Auth

[Docs](https://flask-jwt-extended.readthedocs.io/en/latest/index.html)
