<template>
	<div class="container">
		<login-form></login-form>
	</div>
</template>

<script>
	import LoginForm from '@/components/auth/LoginForm.vue'
	
	export default {
		components: {
			LoginForm
		}
	}
</script>
