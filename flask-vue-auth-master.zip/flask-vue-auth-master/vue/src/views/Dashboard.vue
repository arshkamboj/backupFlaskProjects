<template>
	<div class="container">
		Dashboard
	</div>
</template>

<script>
	export default {
		
	}
</script>
